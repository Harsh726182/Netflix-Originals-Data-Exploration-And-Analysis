select * from netflix;
#QUESTION-1
select * from netflix where IMDBScore>7 and Runtime >100
 and Language  in  ('english' ,'spanish');
 #Question - 2
 select language ,count(*) as total_titles from netflix
 group by Language
 having count(*)>5;
 #Question - 3
 select title, IMDBScore,runtime from netflix
 where language='hindi'
 order by runtime desc,IMDBScore desc
 limit 3;
 #Question - 4
 select title,IMDBScore from netflix where Title like '%house%' and IMDBScore>6;
 #Question-5
 select * from netflix where Premiere_Date between '01-01-2018' and '31-12-2020'
 and language in ('english','hindi','spanish');
 #question-6
 select Title, Runtime,IMDBScore,Premiere_Date from netflix where runtime<60 and IMDBScore<5
 order by Premiere_Date 
 #Question-7
 select genreid, avg(imdbscore) as average_imdb_score from netflix
 group by GenreID
 having count(*)>=10;
 #Question-8
 select runtime,count(*) as count from netflix
 group by runtime
 order by count desc 
 limit 5;
 #Question-9
 select language, count(title) as total_titles from netflix where premiere_date between '01-01-2020' and '31-12-2020'
 group by language; 
 #QUESTION-10
 create table netfliX_movies (
 ID INT PRIMARY KEY AUTO_INCREMENT,
 Title VARCHAR(255) NOT NULL,
 Imdbscore DECIMAL(3,1) CHECK 
 (Imdbscore >=0 AND Imdbscore<=10),
 runtime INT CHECK (runtime>30),
 premiere_date DATE);
 
 
 
 